---
name: NestWork
colors:
  surface: '#f9faf6'
  surface-dim: '#dadad7'
  surface-bright: '#f9faf6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f1'
  surface-container: '#eeeeeb'
  surface-container-high: '#e8e8e5'
  surface-container-highest: '#e2e3e0'
  on-surface: '#1a1c1a'
  on-surface-variant: '#414844'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f0f1ee'
  outline: '#717973'
  outline-variant: '#c1c8c2'
  surface-tint: '#3f6653'
  primary: '#012d1d'
  on-primary: '#ffffff'
  primary-container: '#1b4332'
  on-primary-container: '#86af99'
  inverse-primary: '#a5d0b9'
  secondary: '#96482d'
  on-secondary: '#ffffff'
  secondary-container: '#fd9979'
  on-secondary-container: '#762f17'
  tertiary: '#401b1b'
  on-tertiary: '#ffffff'
  tertiary-container: '#5a302f'
  on-tertiary-container: '#d29895'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c1ecd4'
  primary-fixed-dim: '#a5d0b9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#274e3d'
  secondary-fixed: '#ffdbd0'
  secondary-fixed-dim: '#ffb59e'
  on-secondary-fixed: '#390b00'
  on-secondary-fixed-variant: '#783118'
  tertiary-fixed: '#ffdad8'
  tertiary-fixed-dim: '#f5b7b4'
  on-tertiary-fixed: '#331111'
  on-tertiary-fixed-variant: '#673a39'
  background: '#f9faf6'
  on-background: '#1a1c1a'
  surface-variant: '#e2e3e0'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.02em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  button:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  container-margin: 20px
  card-gap: 16px
---

## Brand & Style

This design system is built on the philosophy of "Natural Productivity." It targets modern professionals, digital nomads, and remote teams seeking sanctuary-like workspaces. The visual direction follows a **Minimalist-Organic** movement, blending the clean structure of modern SaaS with the warm, earthy tones of interior design.

The UI evokes feelings of calm, focus, and hospitality. By utilizing generous white space and high-contrast nature-inspired tones, the interface recedes into the background, allowing high-quality imagery of workspaces to take center stage. Every interaction is designed to feel light and unburdened, mirroring the relief of finding the perfect desk.

## Colors

The palette is rooted in a natural, grounded aesthetic. The primary background uses an off-white tint to reduce screen glare and provide a "paper-like" tactile quality. 

- **Primary Accent (Deep Forest Green):** Reserved for high-intent actions. It symbolizes stability and growth.
- **Secondary Accent (Soft Terracotta):** Used sparingly to draw attention to status changes, amenities, or special offers.
- **Neutrality:** Grays are avoided in favor of charcoal tones with slight warmth to maintain harmony with the off-white base. 
- **Functional Colors:** Success, warning, and error states should be desaturated to fit the organic theme while remaining accessible.

## Typography

**Plus Jakarta Sans** is the sole typeface for this design system, chosen for its modern geometry and friendly open counters. 

The typographic hierarchy prioritizes wide letter spacing (tracking) in body and label styles to enhance the "airy" feel. Headlines use a slightly tighter tracking and heavier weight to provide clear structural anchors for the eye. All text uses the Deep Charcoal color to ensure AA/AAA accessibility against the off-white and white surfaces.

## Layout & Spacing

This design system employs a **Fluid-Organic Grid** model. While adhering to a standard mobile 4-column structure, it leans heavily on "Generous Breathability"—using larger-than-standard margins and internal paddings.

- **Rhythm:** A 4px baseline grid ensures consistent vertical alignment.
- **Margins:** Screen edges maintain a minimum 20px margin to prevent the UI from feeling cramped.
- **Sectioning:** Vertical white space between logical sections should prioritize the `xxl` (48px) token to maintain the light, airy atmosphere.

## Elevation & Depth

Depth is conveyed through **Tonal Layering** and **Ambient Diffusion** rather than harsh shadows.

- **The Surface:** The primary background is the base layer.
- **The Card:** Elements sit on a pure white (#FFFFFF) surface. 
- **The Shadow:** Shadows are extremely soft (0% to 5% opacity) with a large blur radius (20px+) and a slight tint of the Primary color to make the elevation feel natural.
- **The Modal:** Bottom sheets utilize a backdrop blur (12px) on the obscured content to maintain a sense of space and context while focusing the user.

## Shapes

The shape language is defined by **High Circularity**. Hard corners are non-existent in this design system.

- **Primary Cards:** Use a significant 24px radius to create a soft, welcoming enclosure.
- **Interactive Elements:** Buttons and tags use a pill-shape (fully rounded) to differentiate them from static containers.
- **Bottom Sheets:** Top corners feature a 32px radius to soften the transition from the bottom of the screen.

## Components

### Buttons
Primary buttons are solid Deep Forest Green with white text, featuring a pill-shaped geometry. Secondary buttons are outlined in a thin stroke of the primary color or utilize a ghost style for lower emphasis.

### Chips & Tags
Used for amenities (e.g., "High-speed Wi-Fi") or status. These are pill-shaped with the Soft Terracotta background at 15% opacity and the text at 100% opacity for a sophisticated, layered look.

### Cards
Workspace cards feature large-scale imagery at the top with a 24px corner radius. Content inside the card is padded by 20px. The card itself should have a subtle ambient shadow to lift it from the off-white background.

### Bottom Sheets
Must include a 40x4px centered handle bar in a light charcoal color. The transition should be a smooth "ease-out" motion.

### Input Fields
Inputs use the Soft White background with a subtle 1px border. When focused, the border transitions to Deep Forest Green. 

### Transition Indicators
Loading states and page transitions should use a slow, fluid animation style (e.g., a "breathing" pulse) rather than a frantic spinning motion to preserve the calm brand personality.