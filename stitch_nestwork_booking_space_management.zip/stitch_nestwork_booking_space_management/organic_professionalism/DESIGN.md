---
name: Organic Professionalism
colors:
  surface: '#fbf9f4'
  surface-dim: '#dbdad5'
  surface-bright: '#fbf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ee'
  surface-container: '#f0eee9'
  surface-container-high: '#eae8e3'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c19'
  on-surface-variant: '#414844'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ec'
  outline: '#717973'
  outline-variant: '#c1c8c2'
  surface-tint: '#3f6653'
  primary: '#012d1d'
  on-primary: '#ffffff'
  primary-container: '#1b4332'
  on-primary-container: '#86af99'
  inverse-primary: '#a5d0b9'
  secondary: '#96482d'
  on-secondary: '#ffffff'
  secondary-container: '#fd9979'
  on-secondary-container: '#762f17'
  tertiary: '#002d1c'
  on-tertiary: '#ffffff'
  tertiary-container: '#00452e'
  on-tertiary-container: '#75b393'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c1ecd4'
  primary-fixed-dim: '#a5d0b9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#274e3d'
  secondary-fixed: '#ffdbd0'
  secondary-fixed-dim: '#ffb59e'
  on-secondary-fixed: '#390b00'
  on-secondary-fixed-variant: '#783118'
  tertiary-fixed: '#b1f0ce'
  tertiary-fixed-dim: '#95d4b3'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#0e5138'
  background: '#fbf9f4'
  on-background: '#1b1c19'
  surface-variant: '#e4e2dd'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  h1:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  h2:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  margin-mobile: 20px
  gutter: 16px
---

## Brand & Style
The design system is built upon a philosophy of "Organic Professionalism." It bridges the gap between the high-pressure world of Indian corporate life and the serene, focused environment of a premium co-working space. The style utilizes a **Minimalist** foundation with **Tactile** elements, favoring generous whitespace and a sophisticated color palette that feels grounded in the natural world. 

Visuals should prioritize high-end photography of Indian co-working interiors—showcasing teak woods, lush indoor greenery, and modern architectural lines. The interface stays out of the way, acting as a quiet concierge that facilitates discovery and booking with effortless grace.

## Colors
The palette is anchored by a sophisticated **Deep Forest Green** as the primary driver for action, evoking stability and growth. The **Soft Terracotta** serves as a rhythmic secondary accent, used sparingly to draw attention to status changes or specific notifications, reminiscent of traditional Indian pottery and modern masonry. 

The background uses a warm **Off-White** rather than a sterile pure white, creating a "paper-like" feel that reduces eye strain during long booking sessions. Typography should primarily use the "Text-Main" deep charcoal-green to maintain high contrast while feeling softer than pure black.

## Typography
This design system utilizes **Plus Jakarta Sans** for all levels of the hierarchy. Its soft, rounded terminals and wide apertures provide a welcoming and modern feel that aligns with the "rounded card" aesthetic. 

- **Headlines:** Use Bold weights with slight negative letter spacing to create a compact, premium editorial look.
- **Body:** Use Regular weight with generous line height (1.5x) to ensure legibility during mobile browsing.
- **Labels:** Use Medium or Semi-Bold weights in smaller sizes, occasionally in all-caps for status badges or category tags to create visual distinction without adding new fonts.

## Layout & Spacing
The layout follows a **Fluid Grid** model optimized for mobile-first interactions. It employs a 4-column grid for standard mobile screens with a consistent 20px outer margin to give content "room to breathe." 

The spacing rhythm is based on a **4px baseline shift**. Elements within a card should use `sm` (8px) or `md` (16px) padding, while vertical sections on a page should be separated by `xl` (32px) to maintain a clean, premium feel. Generous whitespace is a functional requirement here to prevent the UI from feeling cluttered in a feature-rich booking environment.

## Elevation & Depth
Elevation in this design system is achieved through **Tonal Layers** and **Ambient Shadows** rather than heavy outlines. 

1.  **Level 0 (Base):** The off-white background (#F8F6F1).
2.  **Level 1 (Cards):** Pure white surfaces (#FFFFFF) with an extremely soft, diffused shadow (Offset: 0, 4; Blur: 20; Opacity: 4% of Primary Color).
3.  **Level 2 (Modals/Bottom Sheets):** These use the same pure white surface but are accompanied by a 40% opacity dark overlay on the background to pull focus.
4.  **Interactive Depth:** Buttons use a subtle inner-glow or a slightly deeper shadow on press to simulate a physical "tap" into the surface.

## Shapes
The shape language is defined by **Rounded (Level 2)** settings. The core of the visual identity is the **16px radius** applied to all primary content cards. 

- **Buttons & Inputs:** Use a 12px radius to feel substantial yet slightly more "contained" than the cards they sit on.
- **Bottom Sheets:** Use a highly pronounced 24px radius on the top corners to emphasize the "nested" feeling of the modal.
- **Status Badges:** Use a fully rounded "pill" shape to distinguish them from interactive buttons.

## Components

### Buttons
- **Primary:** Deep Forest Green background, white text, 12px radius. Height: 56px for main CTAs.
- **Secondary:** Transparent background, Deep Forest Green border (1px), Deep Forest Green text.

### Cards & Discovery
- **Property Card:** 16px radius, white background. Features a top-aligned image with a 12px inner-padding for the content container.
- **Status Badges:** Small pill-shaped containers. "Available" uses Forest Green tint, "Filling Fast" uses Soft Terracotta, "Full" uses a neutral grey.

### Navigation & Inputs
- **Bottom Navigation:** A clean white bar with a subtle top border. Active states use the Deep Forest Green for the icon and a small 4px dot indicator underneath.
- **Search Bar:** 12px radius, white surface, with a "Terracotta" filter icon to the right.
- **Date/Time Picker:** Presented via a bottom-sheet modal. Selected dates use a Forest Green circle; today's date is underlined in Terracotta.

### Specialized
- **QR Codes:** Nested within a 16px white card with a subtle "Safe to Entry" label in the Forest Green.
- **Issue Forms:** Utilize "Floating Label" inputs with a 12px radius. The "Submit" button remains pinned to the bottom of the viewport above the keyboard.